'use client';

import { use, useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Committee, DelegateStatus } from '@/lib/types';
import { getCountryByName, getFlagUrl } from '@/lib/countries';
import { Emoji } from '@/components/Emoji';
import { getCommitteeByCode, setPhase as setPhaseInDB, setDelegateStatus as setDelegateStatusInDB, updateDocumentStatus as updateDocumentStatusInDB } from '@/lib/committeeService';
import { useSettingsStore } from '@/lib/settingsStore';
import { SettingsPanel } from '@/components/SettingsPanel';

function abbreviateCommitteeName(name: string): string {
  return name
    .replace(/\bUN\s+Security\s+Council\b/gi, 'UNSC')
    .replace(/\bUN\s+General\s+Assembly\b/gi, 'UNGA')
    .replace(/\bUN\s+Human\s+Rights\s+Council\b/gi, 'UNHRC')
    .replace(/United Nations Security Council/gi, 'UNSC')
    .replace(/Security Council/gi, 'UNSC')
    .replace(/United Nations General Assembly/gi, 'UNGA')
    .replace(/General Assembly/gi, 'UNGA')
    .replace(/United Nations Human Rights Council/gi, 'UNHRC')
    .replace(/Human Rights Council/gi, 'HRC')
    .replace(/^UN\s+/i, '');
}

type VoteChoice = 'for' | 'against' | 'for-rights' | 'against-rights' | 'abstain';
interface DelegateVote {
  delegateId: string;
  country: string;
  choice: VoteChoice;
}

type VotingPhase = 'voting' | 'rights-speakers' | 'result';

// ── Roll call modal — defined OUTSIDE VotingPage so React never remounts it ──
// (defining it inside caused new function type each render → unmount/remount → no CSS transitions)
function RollCallModal({
  delegates,
  rollCallStatuses,
  onCycleStatus,
  onConfirm,
}: {
  delegates: Committee['delegates'];
  rollCallStatuses: Record<string, DelegateStatus>;
  onCycleStatus: (id: string) => void;
  onConfirm: () => void;
}) {
  const sorted = [...delegates].sort((a, b) => a.country.localeCompare(b.country));
  const thumbPos = (status: DelegateStatus) =>
    status === 'absent' ? 'left-[2px]' : status === 'present' ? 'left-[32px]' : 'left-[62px]';
  const thumbColor = (status: DelegateStatus) =>
    status === 'absent' ? 'bg-[#8B2020]' : status === 'present' ? 'bg-[#3D7A52]' : 'bg-[#B6871F]';
  const presentCount = Object.values(rollCallStatuses).filter((s) => s !== 'absent').length;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(5,4,3,0.92)', backdropFilter: 'blur(4px)' }}>
      <div className="rounded-2xl w-full max-w-md shadow-2xl flex flex-col" style={{ maxHeight: '85vh', backgroundColor: '#1B3828', border: '1px solid rgba(255,255,255,0.12)' }}>
        <div className="px-5 py-4 shrink-0" style={{ borderBottom: '1px solid rgba(255,255,255,0.12)' }}>
          <h2 className="text-base font-black text-white">Roll Call</h2>
          <p className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.5)' }}>
            {presentCount} of {delegates.length} delegates present — confirm before voting
          </p>
        </div>
        <div className="flex-1 overflow-y-auto px-2 py-2 space-y-0.5">
          {sorted.map((d) => {
            const status = rollCallStatuses[d.id] ?? d.status;
            return (
              <div
                key={d.id}
                className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition-all"
                style={{
                  backgroundColor: status === 'present' ? 'rgba(61,122,82,0.22)' : status === 'present-voting' ? 'rgba(182,135,31,0.18)' : 'transparent',
                  opacity: status === 'absent' ? 0.4 : 1,
                  border: status === 'present' ? '1px solid rgba(61,122,82,0.4)' : status === 'present-voting' ? '1px solid rgba(182,135,31,0.35)' : '1px solid transparent',
                }}
              >
                <div className="w-9 h-9 rounded-full bg-[#DDD4C0] border border-[#C8BAA8] flex items-center justify-center shrink-0 overflow-hidden">
                  {(() => { const f = getCountryByName(d.country); return f ? <img src={getFlagUrl(f.code)} alt={f.code} className="w-6 h-6 object-contain" onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }} /> : <Emoji size="1.25rem">🌐</Emoji>; })()}
                </div>
                <span className="flex-1 text-sm text-white truncate">{d.country}</span>
                <button
                  onClick={() => onCycleStatus(d.id)}
                  className="relative w-[90px] h-[30px] rounded-full cursor-pointer shrink-0 select-none"
                  style={{ backgroundColor: 'rgba(255,255,255,0.10)', border: '1.5px solid rgba(255,255,255,0.22)' }}
                  title="Tap to cycle: Absent → Present → PV"
                >
                  <div className="absolute inset-0 grid grid-cols-3 items-center pointer-events-none">
                    <span className={`text-[10px] font-bold text-center ${status === 'absent' ? 'text-white' : 'text-white/40'}`}>A</span>
                    <span className={`text-[10px] font-bold text-center ${status === 'present' ? 'text-white' : 'text-white/40'}`}>P</span>
                    <span className={`text-[10px] font-bold text-center ${status === 'present-voting' ? 'text-white' : 'text-white/40'}`}>PV</span>
                  </div>
                  <div className={`absolute top-[2px] w-[26px] h-[22px] rounded-full transition-all duration-200 shadow-sm ${thumbPos(status)} ${thumbColor(status)}`} />
                </button>
              </div>
            );
          })}
        </div>
        <div className="px-4 py-4 shrink-0" style={{ borderTop: '1px solid rgba(255,255,255,0.12)' }}>
          <button
            onClick={onConfirm}
            disabled={presentCount === 0}
            className="w-full py-3 rounded-xl font-black text-sm transition-colors"
            style={{
              backgroundColor: presentCount > 0 ? '#EDE7D8' : 'rgba(255,255,255,0.15)',
              color: presentCount > 0 ? '#1C1410' : 'rgba(255,255,255,0.4)',
            }}
          >
            {presentCount > 0 ? `Start Voting with ${presentCount} delegates →` : 'Mark at least 1 delegate present'}
          </button>
        </div>
      </div>
    </div>
  );
}

function getFlag(country: string) {
  const found = getCountryByName(country);
  return found
    ? <img src={getFlagUrl(found.code)} alt={found.code} className="inline-block object-contain" style={{ width: '1em', height: '1em' }} onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }} />
    : <Emoji size="1em">🌐</Emoji>;
}

function VoteScale({ forCount, againstCount, totalVoted }: {
  forCount: number; againstCount: number; totalVoted: number;
}) {
  const forPct = totalVoted > 0 ? (forCount / totalVoted) * 50 : 0;
  const againstPct = totalVoted > 0 ? (againstCount / totalVoted) * 50 : 0;
  return (
    <div className="w-full max-w-2xl px-4">
      <div className="relative h-7 bg-[#EDE7D8] rounded-full overflow-hidden border border-[#DDD4C0]">
        <div
          className="absolute right-1/2 top-0 bottom-0 bg-red-500/70 transition-all duration-300"
          style={{ width: `${againstPct}%` }}
        />
        <div
          className="absolute left-1/2 top-0 bottom-0 bg-green-500/70 transition-all duration-300"
          style={{ width: `${forPct}%` }}
        />
        <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-[#9A8A78] -translate-x-px" />
      </div>
      <div className="flex justify-between mt-1.5 text-xs font-bold">
        <span className="text-red-400">← {againstCount} Against</span>
        <span className="text-[#9A8A78] text-[10px] font-normal">{totalVoted} voted</span>
        <span className="text-green-400">{forCount} For →</span>
      </div>
    </div>
  );
}

export default function VotingPage({ params }: { params: Promise<{ code: string }> }) {
  const { code } = use(params);
  const router = useRouter();

  // ── ALL hooks must be called before any early returns ──────────────────────
  const getSettings = useSettingsStore((s) => s.getSettings);
  const [committee, setCommittee] = useState<Committee | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedDocId, setSelectedDocId] = useState<string | null>(null);
  const [votes, setVotes] = useState<DelegateVote[]>([]);
  const [phase, setPhase] = useState<VotingPhase>('voting');
  const [currentVoterIndex, setCurrentVoterIndex] = useState(0);
  const [rightsIndex, setRightsIndex] = useState(0);
  const [rightsSpeakerTime, setRightsSpeakerTime] = useState(60);
  const [rightsRunning, setRightsRunning] = useState(false);
  const rightsTimerRef = useRef<NodeJS.Timeout | null>(null);
  const [rollCallDone, setRollCallDone] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  // Local delegate statuses for roll call modal (mirrors committee.delegates)
  const [rollCallStatuses, setRollCallStatuses] = useState<Record<string, DelegateStatus>>({});
  const [rightsTimerLimit, setRightsTimerLimit] = useState(60);
  const [showEndDebateConfirm, setShowEndDebateConfirm] = useState(false);
  const [orderedRights, setOrderedRights] = useState<DelegateVote[]>([]);
  const dragIndexRef = useRef<number | null>(null);
  const resultPersistedRef = useRef(false);

  useEffect(() => {
    async function load() {
      const found = await getCommitteeByCode(code);
      setCommittee(found ?? null);
      if (found) {
        const statuses: Record<string, DelegateStatus> = {};
        found.delegates.forEach((d) => { statuses[d.id] = d.status; });
        setRollCallStatuses(statuses);
      }
      setLoading(false);
    }
    load();
  }, [code]);

  useEffect(() => {
    if (committee) document.title = `${abbreviateCommitteeName(committee.name)} — Voting`;
    return () => { document.title = 'Gavelling'; };
  }, [committee?.name]);

  // Rights speaker countdown timer
  useEffect(() => {
    if (rightsRunning) {
      rightsTimerRef.current = setInterval(() => {
        setRightsSpeakerTime((prev) => {
          if (prev <= 1) { setRightsRunning(false); return 0; }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (rightsTimerRef.current) { clearInterval(rightsTimerRef.current); rightsTimerRef.current = null; }
    }
    return () => { if (rightsTimerRef.current) { clearInterval(rightsTimerRef.current); rightsTimerRef.current = null; } };
  }, [rightsRunning]);

  // Reset rights timer when speaker index or limit changes
  useEffect(() => {
    setRightsSpeakerTime(rightsTimerLimit);
    setRightsRunning(false);
  }, [rightsIndex, rightsTimerLimit]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F6F1E9] flex items-center justify-center">
        <img src="/loading.gif" alt="Loading..." className="w-24 h-24 object-contain" />
      </div>
    );
  }

  if (!committee) {
    return (
      <div className="min-h-screen bg-[#F6F1E9] flex items-center justify-center">
        <div className="text-center">
          <div className="mb-4"><Emoji size="2.5rem">🔍</Emoji></div>
          <h1 className="text-2xl font-bold text-[#1C1410] mb-2">Committee not found</h1>
          <p className="text-[#6A5A4A] mb-6">Code &ldquo;{code}&rdquo; is invalid or the session ended.</p>
          <Link href="/" className="bg-[#1B3828] hover:bg-[#2A5A3C] text-white px-6 py-3 rounded-lg font-semibold transition-colors">
            Go Home
          </Link>
        </div>
      </div>
    );
  }

  // ── committee is guaranteed non-null from here ─────────────────────────────
  const settings = getSettings(committee.code);

  const allDRs = (committee.documents ?? []).filter(
    (d) => d.type === 'draft-resolution' &&
      ['introduced', 'passed', 'failed'].includes(d.status)
  );
  const selectedDoc = allDRs.find((d) => d.id === selectedDocId) ?? null;
  // Use roll call statuses (local) if roll call is done, else use DB status
  const presentDelegates = committee.delegates
    .filter((d) => (rollCallDone ? rollCallStatuses[d.id] ?? d.status : d.status) !== 'absent')
    .sort((a, b) => a.country.localeCompare(b.country));

  const forCount = votes.filter((v) => v.choice === 'for' || v.choice === 'for-rights').length;
  const againstCount = votes.filter((v) => v.choice === 'against' || v.choice === 'against-rights').length;
  const abstainCount = votes.filter((v) => v.choice === 'abstain').length;
  const withRightsAll = votes
    .filter((v) => v.choice === 'for-rights' || v.choice === 'against-rights')
    .sort((a, b) => a.country.localeCompare(b.country));
  const withRights = withRightsAll.slice(0, 10);

  // Veto check (2c: use vetoCountries if set, else fall back to p5Delegations then hardcoded P5)
  const vetoList = settings.vetoCountries?.length
    ? settings.vetoCountries
    : (settings.p5Delegations?.length ? settings.p5Delegations : ["China","France","Russia","United Kingdom","United States"]);
  const p5Veto = settings.vetoMode === 'p5'
    && votes.some((v) => vetoList.includes(v.country) && (v.choice === 'against' || v.choice === 'against-rights'));
  const unanimousRequired = settings.vetoMode === 'unanimous';
  // Unanimous: every present delegate (P and PV) must vote 'for' or 'for-rights'
  const presentAndPvDelegates = committee.delegates.filter(
    (d) => (rollCallStatuses[d.id] ?? d.status) !== 'absent'
  );
  const unanimousFail =
    unanimousRequired &&
    phase === 'result' &&
    presentAndPvDelegates.some((d) => {
      const vote = votes.find((v) => v.delegateId === d.id);
      return !vote || (vote.choice !== 'for' && vote.choice !== 'for-rights');
    });

  // Threshold check (substantive votes)
  const totalDecisive = forCount + againstCount; // abstentions excluded from denominator
  let thresholdMet = false;
  if (settings.substantiveThreshold === 'supermajority-2-3') {
    thresholdMet = totalDecisive > 0 && forCount >= (2 / 3) * totalDecisive;
  } else if (settings.substantiveThreshold === 'consensus') {
    thresholdMet = againstCount === 0 && forCount > 0;
  } else {
    // simple majority: more for than against
    thresholdMet = forCount > againstCount;
  }

  const passed = !p5Veto && !unanimousFail && thresholdMet;

  const persistResult = (docId: string, result: 'passed' | 'failed') => {
    if (resultPersistedRef.current) return;
    resultPersistedRef.current = true;
    updateDocumentStatusInDB(docId, result);
    // Update local committee state so the DR list reflects the result immediately
    setCommittee((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        documents: prev.documents.map((d) =>
          d.id === docId ? { ...d, status: result } : d
        ),
      };
    });
  };

  const startNewVote = (docId: string) => {
    setSelectedDocId(docId);
    setVotes([]);
    setPhase('voting');
    setCurrentVoterIndex(0);
    setRightsIndex(0);
    setOrderedRights([]);
    resultPersistedRef.current = false;
  };

  const castVoteAndAdvance = (delegateId: string, country: string, choice: VoteChoice) => {
    setVotes((prev) => {
      const existing = prev.find((v) => v.delegateId === delegateId);
      if (existing) return prev.map((v) => v.delegateId === delegateId ? { ...v, choice } : v);
      return [...prev, { delegateId, country, choice }];
    });
    setCurrentVoterIndex((i) => i + 1);
  };

  const handleFinishVoting = () => {
    if (withRights.length > 0) {
      setOrderedRights([...withRights]);
      setPhase('rights-speakers');
      setRightsIndex(0);
    } else {
      setPhase('result');
      if (selectedDoc) persistResult(selectedDoc.id, passed ? 'passed' : 'failed');
    }
  };

  const handleNextRightsSpeaker = () => {
    if (rightsIndex + 1 >= orderedRights.length) {
      setPhase('result');
      if (selectedDoc) persistResult(selectedDoc.id, passed ? 'passed' : 'failed');
    } else {
      setRightsIndex((i) => i + 1);
    }
  };

  const handleBackToSession = async () => {
    await setPhaseInDB(committee.id, 'speakers-list');
    router.push(`/chair/${committee.code}`);
  };
  const handleEndDebate = async () => {
    await setPhaseInDB(committee.id, 'adjourned');
    router.push('/');
  };

  const Header = ({ children }: { children?: React.ReactNode }) => (
    <header className="border-b border-[#DDD4C0] bg-[#FAF8F3] px-6 h-12 flex items-center gap-4 shrink-0">
      <Link href="/">
        <img
          src="/GavellingLogo.png"
          alt="Gavelling"
          className="w-[16vw] h-auto max-h-8 object-contain"
          onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
        />
      </Link>
      <div className="flex-1 min-w-0 flex items-center gap-2">
        <span className="text-sm font-bold text-[#1C1410] truncate">{abbreviateCommitteeName(committee.name)}</span>
      </div>
      <button
        onClick={handleBackToSession}
        className="text-xs px-3 py-1.5 rounded-lg font-black transition-colors shrink-0"
        style={{ backgroundColor: '#1B3828', color: '#EED98A' }}
        onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = '#2A5A3C'; }}
        onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = '#1B3828'; }}
      >
        ← Back to Session
      </button>
      <button
        onClick={() => setShowEndDebateConfirm(true)}
        className="text-xs px-3 py-1.5 rounded-lg font-black transition-colors shrink-0"
        style={{ backgroundColor: '#8B2020', color: 'white' }}
        onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = '#A03030'; }}
        onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = '#8B2020'; }}
      >
        End Debate
      </button>
      <button onClick={() => setShowSettings(true)} className="text-[#9A8A78] hover:text-[#1C1410] transition-colors shrink-0 text-2xl">⚙</button>
      {children}
    </header>
  );

  // ── Roll call modal (blocks until dismissed) ─────────────────────────────
  const cycleRollCallStatus = (id: string) => {
    setRollCallStatuses((prev) => {
      const cur = prev[id] ?? 'absent';
      const next: DelegateStatus = cur === 'absent' ? 'present' : cur === 'present' ? 'present-voting' : 'absent';
      setDelegateStatusInDB(id, next);
      return { ...prev, [id]: next };
    });
  };

  // ── Doc selection screen ──────────────────────────────────────────────────
  if (!selectedDoc) {
    return (
      <div className="min-h-screen bg-[#F6F1E9] flex flex-col">
        <Header />
        {!rollCallDone && (
          <RollCallModal
            delegates={committee.delegates}
            rollCallStatuses={rollCallStatuses}
            onCycleStatus={cycleRollCallStatus}
            onConfirm={() => setRollCallDone(true)}
          />
        )}
        {showSettings && <SettingsPanel committee={committee} onClose={() => setShowSettings(false)} />}
        <div className="flex-1 flex items-center justify-center">
          <div className="w-96 space-y-3">
            <p className="text-xs font-mono text-[#9A8A78] text-center mb-5 tracking-widest">
              SELECT DRAFT RESOLUTION TO VOTE ON
            </p>
            {allDRs.length === 0 ? (
              <p className="text-sm text-[#9A8A78] text-center py-8">No introduced draft resolutions.</p>
            ) : (
              allDRs.map((doc) => {
                const isVoted = doc.status === 'passed' || doc.status === 'failed';
                return (
                  <button
                    key={doc.id}
                    onClick={() => !isVoted && startNewVote(doc.id)}
                    disabled={isVoted}
                    className={`w-full text-left px-4 py-4 rounded-xl border transition-colors ${
                      isVoted
                        ? 'border-[#DDD4C0] bg-[#F6F1E9] opacity-60 cursor-not-allowed'
                        : 'border-[#DDD4C0] bg-[#EDE7D8] text-[#6A5A4A] hover:border-[#1B3828]/60 hover:bg-[#1B3828]/10'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-0.5">
                      <span className="text-xs font-mono font-bold text-[#1B3828]">{doc.docCode}</span>
                      {doc.status === 'passed' && (
                        <span className="text-[10px] font-bold text-green-400 bg-green-950/40 border border-green-800/40 px-2 py-0.5 rounded-full">✓ PASSED</span>
                      )}
                      {doc.status === 'failed' && (
                        <span className="text-[10px] font-bold text-red-400 bg-red-950/40 border border-red-800/40 px-2 py-0.5 rounded-full">✗ FAILED</span>
                      )}
                    </div>
                    <span className="text-base font-bold text-[#1C1410] block">{doc.title}</span>
                    {doc.sponsors.length > 0 && (
                      <span className="text-xs text-[#9A8A78] block mt-1">Sponsors: {doc.sponsors.join(', ')}</span>
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>
      </div>
    );
  }

  const currentDelegate = currentVoterIndex < presentDelegates.length
    ? presentDelegates[currentVoterIndex]
    : null;
  const upcomingDelegates = presentDelegates.slice(currentVoterIndex + 1, currentVoterIndex + 6);

  return (
    <div className="h-screen bg-[#F6F1E9] flex flex-col overflow-hidden">
      <Header>
        <span className="text-xs font-mono font-bold text-[#1B3828] bg-[#DDD4C0] px-2 py-0.5 rounded shrink-0">
          {selectedDoc.docCode}
        </span>
        <span className="text-sm font-bold text-[#1C1410] truncate hidden sm:block">{selectedDoc.title}</span>
        <span className="text-xs text-[#9A8A78] shrink-0">
          {Math.min(currentVoterIndex, presentDelegates.length)}/{presentDelegates.length} voted
        </span>
        <button
          onClick={() => setSelectedDocId(null)}
          className="text-xs text-[#9A8A78] hover:text-[#6A5A4A] transition-colors shrink-0"
        >
          ← DRs
        </button>
      </Header>

      {/* ── Active voting: one delegate at a time ── */}
      {phase === 'voting' && currentDelegate && (
        <div className="flex-1 flex flex-col items-center py-6 px-4 overflow-hidden">
          {/* Current voter */}
          <div className="flex-1 flex flex-col items-center justify-center min-h-0">
            <div className="select-none mb-3 flex items-center justify-center">
              {(() => {
                const f = getCountryByName(currentDelegate.country);
                const size = 'min(33vw, 27vh)';
                return f ? (
                  <div style={{ width: size, aspectRatio: '3 / 2', borderRadius: '14px', overflow: 'hidden', boxShadow: '0 0 0 3.75px rgba(28,20,16,0.22)', flexShrink: 0 }}>
                    <img
                      src={getFlagUrl(f.code)}
                      alt={f.code}
                      style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
                      onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                    />
                  </div>
                ) : (
                  <div style={{ width: size, aspectRatio: '3 / 2', borderRadius: '14px', overflow: 'hidden', boxShadow: '0 0 0 3.75px rgba(28,20,16,0.22)', flexShrink: 0, position: 'relative', backgroundColor: 'rgba(221,212,192,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Emoji size="5rem">🌐</Emoji>
                  </div>
                );
              })()}
            </div>
            <h1
              style={{ fontSize: 'min(5.5vw, 5vh)' }}
              className="font-black text-[#1C1410] text-center leading-tight mb-1"
            >
              {currentDelegate.country}
            </h1>
            <p className="text-[#9A8A78] text-sm">
              {currentVoterIndex + 1} of {presentDelegates.length}
            </p>
          </div>

          {/* Vote buttons */}
          <div className="flex gap-3 w-full max-w-3xl mb-4">
            <button
              onClick={() => castVoteAndAdvance(currentDelegate.id, currentDelegate.country, 'for')}
              className="flex-1 bg-[#2A7A3C] hover:bg-[#3D8A52] border border-[#2A7A3C] text-white font-black text-base py-6 rounded-2xl transition-colors"
            >
              In Favour
            </button>
            <button
              onClick={() => castVoteAndAdvance(currentDelegate.id, currentDelegate.country, 'for-rights')}
              className="flex-1 bg-[#1B5C2E] hover:bg-[#2A7A3C] border border-[#3D7A52] text-[#EED98A] font-black text-sm py-6 rounded-2xl transition-colors leading-snug"
            >
              In Favour<br />with Rights
            </button>
            {(rollCallStatuses[currentDelegate.id] ?? currentDelegate.status) === 'present' ? (
              <button
                onClick={() => castVoteAndAdvance(currentDelegate.id, currentDelegate.country, 'abstain')}
                className="flex-1 bg-[#DDD4C0] hover:bg-[#C8BAA8] border border-[#C8BAA8] text-[#6A5A4A] font-black text-base py-6 rounded-2xl transition-colors"
              >
                Abstain
              </button>
            ) : (
              <button disabled className="flex-1 bg-[#EDE7D8] border border-[#DDD4C0] text-[#9A8A78] font-black text-base py-6 rounded-2xl opacity-40 cursor-not-allowed">
                Abstain (P+V)
              </button>
            )}
            <button
              onClick={() => castVoteAndAdvance(currentDelegate.id, currentDelegate.country, 'against-rights')}
              className="flex-1 bg-[#7A2020] hover:bg-[#8B3030] border border-[#7A2020] text-[#EED98A] font-black text-sm py-6 rounded-2xl transition-colors leading-snug"
            >
              Against<br />with Rights
            </button>
            <button
              onClick={() => castVoteAndAdvance(currentDelegate.id, currentDelegate.country, 'against')}
              className="flex-1 bg-[#8B2020] hover:bg-[#A03030] border border-[#8B2020] text-white font-black text-base py-6 rounded-2xl transition-colors"
            >
              Against
            </button>
          </div>

          {/* Scale */}
          <div className="mb-4 w-full flex justify-center">
            <VoteScale forCount={forCount} againstCount={againstCount} totalVoted={votes.length} />
          </div>

          {/* Upcoming voters — fixed height, invisible when empty so layout never shifts */}
          <div className={`mt-4 w-full max-w-2xl h-[110px] shrink-0 ${upcomingDelegates.length === 0 ? 'invisible' : ''}`}>
            <p className="text-[10px] text-[#9A8A78] font-mono text-center mb-2 tracking-widest">UP NEXT</p>
            <div className="flex items-center justify-center gap-4 h-[80px]">
              {upcomingDelegates.map((d, i) => {
                const qf = getCountryByName(d.country);
                const qHeight = i === 0 ? 52 : Math.max(20, 38 - i * 5);
                const qWidth = Math.round(qHeight * 1.5);
                const qRadius = i === 0 ? 8 : 5;
                const qShadow = `0 0 0 ${i === 0 ? 2.5 : 1.5}px rgba(28,20,16,0.22)`;
                return (
                  <div key={d.id} className="flex flex-col items-center gap-1" style={{ opacity: Math.max(0.2, 1 - i * 0.18) }}>
                    {qf ? (
                      <div style={{ width: qWidth, height: qHeight, borderRadius: qRadius, overflow: 'hidden', boxShadow: qShadow, flexShrink: 0 }}>
                        <img src={getFlagUrl(qf.code)} alt={qf.code} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }} />
                      </div>
                    ) : (
                      <div style={{ width: qWidth, height: qHeight, borderRadius: qRadius, overflow: 'hidden', boxShadow: qShadow, flexShrink: 0, position: 'relative', backgroundColor: 'rgba(221,212,192,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <Emoji size={`${Math.round(qHeight * 0.65)}px`}>🌐</Emoji>
                      </div>
                    )}
                    <span className="text-[9px] text-[#9A8A78] text-center max-w-[52px] truncate">{d.country}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ── All voted — proceed screen ── */}
      {phase === 'voting' && !currentDelegate && (
        <div className="flex-1 flex flex-col items-center justify-center px-8 gap-6">
          <Emoji size="3.75rem">🗳️</Emoji>
          <h2 className="text-3xl font-black text-[#1C1410]">
            All {presentDelegates.length} delegates have voted
          </h2>
          <div className="flex gap-10 text-center">
            <div>
              <div className="text-4xl font-black text-green-400">{forCount}</div>
              <div className="text-[#6A5A4A] text-sm mt-1">For</div>
            </div>
            <div>
              <div className="text-4xl font-black text-red-400">{againstCount}</div>
              <div className="text-[#6A5A4A] text-sm mt-1">Against</div>
            </div>
            {abstainCount > 0 && (
              <div>
                <div className="text-4xl font-black text-[#6A5A4A]">{abstainCount}</div>
                <div className="text-[#9A8A78] text-sm mt-1">Abstain</div>
              </div>
            )}
            {withRights.length > 0 && (
              <div>
                <div className="text-4xl font-black text-amber-400">{withRights.length}</div>
                <div className="text-[#6A5A4A] text-sm mt-1">w/ Rights</div>
              </div>
            )}
          </div>
          <VoteScale forCount={forCount} againstCount={againstCount} totalVoted={votes.length} />
          <button
            onClick={handleFinishVoting}
            className="bg-[#1B3828] hover:bg-[#2A5A3C] text-white px-12 py-4 rounded-2xl font-black text-lg transition-colors mt-2"
          >
            {withRights.length > 0
              ? `Proceed to Rights Speakers (${withRights.length}) →`
              : 'See Final Result →'}
          </button>
        </div>
      )}

      {/* ── Rights speakers ── */}
      {phase === 'rights-speakers' && orderedRights.length > 0 && (
        <div className="flex-1 flex flex-col items-center justify-between py-8 px-8 overflow-hidden">
          <div className="flex-1 flex flex-col items-center justify-center min-h-0">
            <p className="text-xs text-amber-400 font-mono tracking-widest mb-6">
              RIGHTS SPEAKERS — {rightsIndex + 1} OF {orderedRights.length}
            </p>
            <div className="select-none mb-3 flex items-center justify-center">
              {(() => {
                const f = getCountryByName(orderedRights[rightsIndex].country);
                const size = 'min(27vw, 24vh)';
                return f ? (
                  <div style={{ width: size, aspectRatio: '3 / 2', borderRadius: '14px', overflow: 'hidden', boxShadow: '0 0 0 3.75px rgba(28,20,16,0.22)', flexShrink: 0 }}>
                    <img
                      src={getFlagUrl(f.code)}
                      alt={f.code}
                      style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
                      onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                    />
                  </div>
                ) : (
                  <div style={{ width: size, aspectRatio: '3 / 2', borderRadius: '14px', overflow: 'hidden', boxShadow: '0 0 0 3.75px rgba(28,20,16,0.22)', flexShrink: 0, position: 'relative', backgroundColor: 'rgba(221,212,192,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Emoji size="5rem">🌐</Emoji>
                  </div>
                );
              })()}
            </div>
            <h1
              style={{ fontSize: 'min(5vw, 4vh)' }}
              className="font-black text-[#1C1410] text-center mb-2"
            >
              {orderedRights[rightsIndex].country}
            </h1>
            <p className="text-amber-400 font-semibold">
              {orderedRights[rightsIndex].choice === 'for-rights' ? '★ In Favour with Rights' : '★ Against with Rights'}
            </p>
            {/* Rights speaker countdown timer */}
            <div className={`text-6xl font-black font-mono mt-4 tabular-nums ${rightsSpeakerTime <= 10 ? 'text-red-500' : rightsSpeakerTime <= 20 ? 'text-yellow-500' : 'text-[#1C1410]'}`}>
              {Math.floor(rightsSpeakerTime / 60)}:{String(rightsSpeakerTime % 60).padStart(2, '0')}
            </div>
            <div className="flex gap-2 mt-3 flex-wrap justify-center">
              <button
                onClick={() => setRightsRunning((r) => !r)}
                className={`px-6 py-2.5 rounded-xl font-bold text-sm transition-colors ${rightsRunning ? 'bg-yellow-600 hover:bg-yellow-500 text-white' : 'bg-[#2A5A3C] hover:bg-[#3D7A52] text-white'}`}
              >
                {rightsRunning ? '⏸ Pause' : '▶ Start'}
              </button>
              {[30, 45, 60, 90, 120].map((s) => (
                <button key={s} onClick={() => setRightsTimerLimit(s)}
                  className={`px-3 py-2.5 rounded-xl font-bold text-xs transition-colors ${rightsTimerLimit === s ? 'bg-[#1B3828] text-white' : 'bg-[#DDD4C0] text-[#6A5A4A] hover:bg-[#C8BAA8]'}`}>
                  {s}s
                </button>
              ))}
            </div>
          </div>

          <div className="w-full max-w-md space-y-1 mb-4 mt-6 overflow-y-auto" style={{ maxHeight: '220px' }}>
            {orderedRights.slice(rightsIndex).map((v, relIdx) => {
              const absIdx = rightsIndex + relIdx;
              const isCurrent = relIdx === 0;
              return (
                <div
                  key={v.delegateId}
                  draggable={!isCurrent}
                  onDragStart={() => { dragIndexRef.current = absIdx; }}
                  onDragOver={(e) => { if (!isCurrent) e.preventDefault(); }}
                  onDrop={() => {
                    const from = dragIndexRef.current;
                    if (from === null || from === absIdx || from <= rightsIndex || absIdx <= rightsIndex) return;
                    setOrderedRights((prev) => {
                      const arr = [...prev];
                      const [item] = arr.splice(from, 1);
                      arr.splice(absIdx, 0, item);
                      return arr;
                    });
                    dragIndexRef.current = null;
                  }}
                  className={`flex items-center gap-3 px-4 py-2 rounded-lg text-sm transition-all ${
                    isCurrent
                      ? 'bg-[#1B3828] border border-[#3D7A52] text-[#EED98A]'
                      : 'bg-[#FAF8F3] border border-[#DDD4C0] text-[#1C1410] opacity-80 cursor-grab'
                  }`}
                >
                  {!isCurrent && <span className="text-[#9A8A78] text-xs">⠿</span>}
                  <span className="text-xs w-5 font-mono text-right opacity-60">{absIdx + 1}</span>
                  <span>{getFlag(v.country)} {v.country}</span>
                  <span className={`ml-auto text-xs font-semibold ${
                    isCurrent ? 'text-[#EED98A]' :
                    v.choice === 'for-rights' ? 'text-[#2A7A3C]' : 'text-[#8B2020]'
                  }`}>
                    {isCurrent ? 'Speaking' : v.choice === 'for-rights' ? 'For w/ Rights' : 'Against w/ Rights'}
                  </span>
                </div>
              );
            })}
          </div>

          <button
            onClick={() => { setRightsRunning(false); handleNextRightsSpeaker(); }}
            className="w-full max-w-md bg-[#1B3828] hover:bg-[#2A5A3C] text-white py-4 rounded-2xl font-black text-lg transition-colors"
          >
            {rightsIndex + 1 < orderedRights.length ? 'Next Rights Speaker →' : 'See Final Result →'}
          </button>
        </div>
      )}

      {/* ── Final result ── */}
      {phase === 'result' && (
        <div className="flex-1 flex flex-col items-center justify-center px-8 gap-6">
          <p className="text-xs font-mono text-[#9A8A78] tracking-widest uppercase">
            Final Result — {selectedDoc.docCode}
          </p>

          {/* Main result bubble */}
          <div
            className="rounded-3xl px-16 py-12 text-center w-full max-w-xl"
            style={{
              backgroundColor: passed ? '#1B3828' : '#8B2020',
              boxShadow: passed
                ? '0 24px 64px rgba(27,56,40,0.30)'
                : '0 24px 64px rgba(139,32,32,0.30)',
            }}
          >
            <div className="text-6xl font-black mb-3" style={{ color: passed ? '#EED98A' : '#FFD0D0' }}>
              {passed ? '✓ PASSED' : '✗ FAILED'}
            </div>
            <p className="text-xl font-bold mb-6" style={{ color: passed ? 'rgba(238,217,138,0.75)' : 'rgba(255,208,208,0.75)' }}>
              {selectedDoc.title}
            </p>
            <div className="flex justify-center gap-10">
              <div className="text-center">
                <div className="text-4xl font-black" style={{ color: '#6EE7A0' }}>{forCount}</div>
                <div className="text-sm mt-1" style={{ color: passed ? 'rgba(238,217,138,0.6)' : 'rgba(255,208,208,0.6)' }}>For</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-black" style={{ color: '#FCA5A5' }}>{againstCount}</div>
                <div className="text-sm mt-1" style={{ color: passed ? 'rgba(238,217,138,0.6)' : 'rgba(255,208,208,0.6)' }}>Against</div>
              </div>
              {abstainCount > 0 && (
                <div className="text-center">
                  <div className="text-4xl font-black" style={{ color: 'rgba(255,255,255,0.5)' }}>{abstainCount}</div>
                  <div className="text-sm mt-1" style={{ color: passed ? 'rgba(238,217,138,0.6)' : 'rgba(255,208,208,0.6)' }}>Abstain</div>
                </div>
              )}
              {withRights.length > 0 && (
                <div className="text-center">
                  <div className="text-4xl font-black" style={{ color: '#FCD34D' }}>{withRights.length}</div>
                  <div className="text-sm mt-1" style={{ color: passed ? 'rgba(238,217,138,0.6)' : 'rgba(255,208,208,0.6)' }}>w/ Rights</div>
                </div>
              )}
            </div>
            {p5Veto && (
              <p className="text-sm mt-4 font-semibold flex items-center gap-1 justify-center" style={{ color: '#FCA5A5' }}>
                <Emoji size="1em">🛡️</Emoji> P5 veto exercised
              </p>
            )}
            {unanimousFail && (
              <p className="text-sm mt-4 font-semibold" style={{ color: '#FCA5A5' }}>
                ⚠️ Unanimous vote required — one or more delegates voted against or abstained
              </p>
            )}
            {!p5Veto && !unanimousFail && settings.substantiveThreshold === 'supermajority-2-3' && (
              <p className="text-sm mt-3 font-semibold" style={{ color: thresholdMet ? '#6EE7A0' : '#FCA5A5' }}>
                2/3 supermajority required · {forCount}/{totalDecisive} ({totalDecisive > 0 ? Math.round(forCount / totalDecisive * 100) : 0}%)
              </p>
            )}
            {!p5Veto && !unanimousFail && settings.substantiveThreshold === 'consensus' && (
              <p className="text-sm mt-3 font-semibold" style={{ color: thresholdMet ? '#6EE7A0' : '#FCA5A5' }}>
                Consensus required · {againstCount} voted against
              </p>
            )}
          </div>

          <VoteScale forCount={forCount} againstCount={againstCount} totalVoted={votes.length} />

          {/* Action buttons */}
          <div className="flex gap-3">
            <button
              onClick={() => startNewVote(selectedDoc.id)}
              className="py-3 px-6 rounded-xl font-bold transition-colors"
              style={{ backgroundColor: '#DDD4C0', color: '#1B3828', border: '1.5px solid #C8BAA8' }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = '#C8BAA8'; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = '#DDD4C0'; }}
            >
              Vote Again
            </button>
            <button
              onClick={() => setSelectedDocId(null)}
              className="py-3 px-6 rounded-xl font-black transition-colors"
              style={{ backgroundColor: '#1B3828', color: '#EED98A', boxShadow: '0 4px 16px rgba(27,56,40,0.25)' }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = '#2A5A3C'; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = '#1B3828'; }}
            >
              Move to Next DR →
            </button>
            <button
              onClick={() => setShowEndDebateConfirm(true)}
              className="py-3 px-6 rounded-xl font-bold transition-colors"
              style={{ backgroundColor: '#8B2020', color: 'white', border: '1.5px solid #A03030' }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = '#A03030'; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = '#8B2020'; }}
            >
              End Debate
            </button>
          </div>
        </div>
      )}
      {showSettings && <SettingsPanel committee={committee} onClose={() => setShowSettings(false)} />}

      {/* ── End Debate confirmation modal ── */}
      {showEndDebateConfirm && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center"
          style={{ background: 'rgba(5,4,3,0.80)', backdropFilter: 'blur(6px)' }}
          onClick={() => setShowEndDebateConfirm(false)}
        >
          <div
            className="rounded-2xl w-full max-w-sm mx-4 shadow-2xl flex flex-col overflow-hidden"
            style={{ backgroundColor: '#FAF8F3', border: '1px solid #DDD4C0' }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Top bar */}
            <div className="px-6 pt-6 pb-4" style={{ borderBottom: '1px solid #EDE7D8' }}>
              <div className="flex items-center gap-3 mb-1">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center shrink-0 text-xl"
                  style={{ backgroundColor: '#8B2020' }}
                >
                  🔨
                </div>
                <h2 className="text-lg font-black text-[#1C1410]">End Debate?</h2>
              </div>
              <p className="text-sm text-[#6A5A4A] leading-relaxed mt-2">
                This will permanently adjourn the committee. All delegates will be shown a session-closed screen and no further changes can be made.
              </p>
            </div>
            {/* Buttons */}
            <div className="px-6 py-4 flex gap-3">
              <button
                onClick={() => setShowEndDebateConfirm(false)}
                className="flex-1 py-3 rounded-xl font-bold text-sm transition-colors"
                style={{ backgroundColor: '#EDE7D8', color: '#1C1410', border: '1.5px solid #DDD4C0' }}
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = '#DDD4C0'; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = '#EDE7D8'; }}
              >
                Cancel
              </button>
              <button
                onClick={() => { setShowEndDebateConfirm(false); handleEndDebate(); }}
                className="flex-1 py-3 rounded-xl font-black text-sm transition-colors"
                style={{ backgroundColor: '#8B2020', color: 'white' }}
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = '#A03030'; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = '#8B2020'; }}
              >
                Yes, End Debate
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}