'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Mic, Scale, List, FileText, MessageSquare, Save, Users, CreditCard, Zap } from 'lucide-react';
import { getFlagUrl, getCountryByName } from '@/lib/countries';
import SiteNav from '@/components/SiteNav';

const steps = [
  { step: '01', title: 'Create a Committee', desc: 'Chair enters committee name, topic, and delegates. Pick a preset or builds custom.' },
  { step: '02', title: 'Share the Code', desc: 'Delegates, co-chairs, and faculty advisors join instantly with a session code from any device.' },
  { step: '03', title: 'Run the Session', desc: 'Manage roll call, speakers list, motions, and voting — all in one place.' },
];

// ── Individual feature card components ──────────────────────────────────────

function RollCallCard() {
  const shadow = { boxShadow: '0 24px 64px rgba(27,56,40,0.14)' };
  const getFlag = (country: string) => {
    const c = getCountryByName(country);
    return c ? <img src={getFlagUrl(c.code)} alt={country} style={{ width: '28px', height: '20px', objectFit: 'cover', borderRadius: '4px', border: '1px solid rgba(28,20,16,0.10)' }} /> : <span className="w-7 h-5 bg-[#DDD4C0] rounded inline-block" />;
  };
  const delegates = [
    { country: 'China', status: 'present-voting' },
    { country: 'France', status: 'present-voting' },
    { country: 'Germany', status: 'present' },
    { country: 'Brazil', status: 'absent' },
    { country: 'India', status: 'present' },
    { country: 'Japan', status: 'present-voting' },
    { country: 'United Kingdom', status: 'absent' },
    { country: 'South Africa', status: 'present' },
  ];
  return (
    <div className="w-full rounded-2xl overflow-hidden flex flex-col" style={{ ...shadow, minHeight: '460px', backgroundColor: '#1B3828', border: '1px solid #3D7A52' }}>
      {/* Header */}
      <div className="px-5 py-3 flex items-center justify-between" style={{ borderBottom: '1px solid rgba(61,122,82,0.4)' }}>
        <div>
          <p className="font-black text-sm uppercase tracking-widest" style={{ color: '#EED98A', fontFamily: "'DM Mono', monospace" }}>Roll Call</p>
          <p className="text-xs mt-0.5" style={{ color: 'rgba(238,217,138,0.5)' }}>UN Security Council</p>
        </div>
        <span className="text-[9px] font-mono px-2 py-0.5 rounded-full" style={{ backgroundColor: 'rgba(238,217,138,0.15)', color: '#EED98A', border: '1px solid rgba(238,217,138,0.3)' }}>PRE-SESSION</span>
      </div>
      {/* Quick set buttons */}
      <div className="flex gap-2 px-4 py-2.5">
        {['All Present', 'All P+V', 'Clear'].map(btn => (
          <button key={btn} className="flex-1 py-1.5 text-[9px] font-black uppercase rounded-lg" style={{ backgroundColor: 'rgba(238,217,138,0.1)', color: '#EED98A', border: '1px solid rgba(238,217,138,0.2)' }}>{btn}</button>
        ))}
      </div>
      {/* Delegate list */}
      <div className="flex-1 px-3 pb-2 flex flex-col gap-1">
        {delegates.map(d => (
          <div key={d.country} className="flex items-center gap-3 rounded-xl px-3 py-2" style={{ backgroundColor: 'rgba(255,255,255,0.05)' }}>
            {getFlag(d.country)}
            <span className="flex-1 text-xs font-semibold truncate" style={{ color: '#EDE7D8' }}>{d.country}</span>
            <span className="text-[9px] font-bold px-2 py-0.5 rounded-full" style={{
              backgroundColor: d.status === 'present-voting' ? '#EED98A' : d.status === 'present' ? 'rgba(61,122,82,0.5)' : 'rgba(255,255,255,0.08)',
              color: d.status === 'present-voting' ? '#1B3828' : d.status === 'present' ? '#EDE7D8' : '#9A8A78',
            }}>
              {d.status === 'present-voting' ? 'P+V' : d.status === 'present' ? 'P' : 'Absent'}
            </span>
          </div>
        ))}
      </div>
      {/* Quorum bar */}
      <div className="px-4 py-3" style={{ borderTop: '1px solid rgba(61,122,82,0.3)' }}>
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[9px] font-mono uppercase tracking-wide" style={{ color: 'rgba(238,217,138,0.5)' }}>Quorum</span>
          <span className="text-[9px] font-mono font-bold" style={{ color: '#EED98A' }}>6 / 8</span>
        </div>
        <div className="h-1.5 rounded-full overflow-hidden" style={{ backgroundColor: 'rgba(255,255,255,0.1)' }}>
          <div className="h-full rounded-full" style={{ width: '75%', backgroundColor: '#3D7A52' }} />
        </div>
      </div>
    </div>
  );
}

function MotionsCard() {
  const shadow = { boxShadow: '0 24px 64px rgba(27,56,40,0.14)' };
  const getFlag = (country: string) => {
    const c = getCountryByName(country);
    return c ? <img src={getFlagUrl(c.code)} alt={country} style={{ width: '32px', height: '22px', objectFit: 'cover', borderRadius: '6px', border: '1px solid rgba(28,20,16,0.10)' }} /> : null;
  };
  return (
    <div className="w-full rounded-2xl overflow-hidden" style={{ ...shadow, minHeight: '460px', backgroundColor: '#FAF8F3', border: '1px solid #DDD4C0' }}>
      {/* Header */}
      <div className="px-5 py-3 flex items-center justify-between" style={{ borderBottom: '1px solid #DDD4C0' }}>
        <h2 className="text-lg font-black tracking-wide" style={{ color: '#1B3828', fontFamily: "'Outfit', sans-serif" }}>VOTE ON MOTIONS</h2>
      </div>
      {/* Drag hint */}
      <div className="mx-4 mt-3 px-3 py-2 rounded-xl text-xs font-semibold" style={{ backgroundColor: '#1B3828', color: '#EED98A' }}>
        Drag motions to reorder. Most disruptive voted on first by default.
      </div>
      {/* Motion cards */}
      <div className="px-4 pt-3 pb-4 flex flex-col gap-3">
        {/* Primary motion — large */}
        <div className="rounded-2xl p-4 flex flex-col gap-2" style={{ border: '2px solid #1B3828', backgroundColor: 'transparent' }}>
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1">
              <p className="font-black text-base" style={{ color: '#1C1410' }}>Moderated Caucus</p>
              <p className="text-xs font-semibold mt-0.5" style={{ color: '#1B3828' }}>Topic: <span style={{ color: '#1C1410' }}>Nuclear Non-Proliferation</span></p>
              <p className="text-xs mt-1" style={{ color: '#1C1410' }}><span className="font-semibold" style={{ color: '#1B3828' }}>Total Time: </span><span className="font-black">10m</span></p>
              <p className="text-xs" style={{ color: '#1C1410' }}><span className="font-semibold" style={{ color: '#1B3828' }}>Speaker Time: </span><span className="font-black">90s</span></p>
              <p className="text-xs" style={{ color: '#1C1410' }}><span className="font-semibold" style={{ color: '#1B3828' }}>Total Speakers: </span><span className="font-black">6 speakers</span></p>
            </div>
            {getFlag('France')}
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl" style={{ backgroundColor: '#FAF8F3', border: '1px solid #DDD4C0' }}>
            <span className="text-xs font-semibold flex-1" style={{ color: '#1B3828' }}>Simple majority</span>
            <span className="text-xs font-bold" style={{ color: '#1C1410' }}>Needs 8 of 15</span>
          </div>
          <div className="flex gap-2 mt-1">
            <button className="flex-1 py-2 rounded-xl font-black text-xs text-white focus:outline-none" style={{ backgroundColor: '#1B3828', letterSpacing: '0.05em' }}>✓ ACCEPT</button>
            <button className="flex-1 py-2 rounded-xl font-black text-xs focus:outline-none" style={{ backgroundColor: '#DDD4C0', color: '#6A5A4A', letterSpacing: '0.05em' }}>✗ REJECT</button>
            <button className="px-3 py-2 rounded-xl font-black text-xs focus:outline-none" style={{ backgroundColor: 'rgba(182,135,31,0.2)', color: '#B6871F', border: '1px solid rgba(182,135,31,0.4)' }}>EDIT</button>
          </div>
        </div>
        {/* Secondary motion — small */}
        <div className="rounded-2xl p-3 flex items-center gap-3" style={{ border: '1px solid #DDD4C0', backgroundColor: 'transparent' }}>
          <div className="flex-1 min-w-0">
            <p className="font-black text-sm" style={{ color: '#1C1410' }}>Unmoderated Caucus</p>
            <p className="text-xs" style={{ color: '#1C1410' }}><span className="font-semibold" style={{ color: '#1B3828' }}>Total Time: </span><span className="font-black">15m</span></p>
          </div>
          {getFlag('Germany')}
        </div>
      </div>
    </div>
  );
}

function SpeakersCard() {
  const [timerSecs, setTimerSecs] = useState(83);
  useEffect(() => {
    const t = setInterval(() => setTimerSecs(s => s > 0 ? s - 1 : 90), 1000);
    return () => clearInterval(t);
  }, []);
  const mins = Math.floor(timerSecs / 60);
  const secs = timerSecs % 60;
  const shadow = { boxShadow: '0 24px 64px rgba(27,56,40,0.14)' };
  const queueDelegates = [
    { country: 'Denmark', pos: 2 },
    { country: 'Ecuador', pos: 3 },
    { country: 'France', pos: 4 },
    { country: 'Greece', pos: 5 },
    { country: 'Japan', pos: 6 },
  ];
  return (
    <div className="w-full rounded-2xl overflow-hidden" style={{ ...shadow, minHeight: '460px', backgroundColor: '#FAF8F3', border: '1px solid #DDD4C0' }}>
      {/* Top queue row — centered */}
      <div className="px-4 pt-4 pb-2 flex items-start justify-center gap-4 flex-wrap">
        {queueDelegates.map(d => {
          const c = getCountryByName(d.country);
          return (
            <div key={d.country} className="flex flex-col items-center gap-1 flex-shrink-0">
              <div style={{ width: '52px', height: '38px', borderRadius: '10px', overflow: 'hidden', border: '1.5px solid rgba(28,20,16,0.10)' }}>
                {c ? <img src={getFlagUrl(c.code)} alt={d.country} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <div style={{ width: '100%', height: '100%', backgroundColor: '#DDD4C0' }} />}
              </div>
              <span className="text-[9px] font-semibold text-center" style={{ color: '#6A5A4A' }}>{d.country}</span>
              {d.pos === 2 && <span className="text-[8px] font-bold" style={{ color: '#B8844A' }}>Up next</span>}
            </div>
          );
        })}
        <span className="text-xs font-mono self-center flex-shrink-0" style={{ color: '#9A8A78' }}>+8 more</span>
      </div>
      {/* Current speaker */}
      <div className="flex flex-col items-center px-6 py-4">
        <div style={{ width: '100px', height: '72px', borderRadius: '14px', overflow: 'hidden', border: '1.5px solid rgba(28,20,16,0.10)', marginBottom: '12px' }}>
          {(() => { const c = getCountryByName('China'); return c ? <img src={getFlagUrl(c.code)} alt="China" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : null; })()}
        </div>
        <p className="font-black text-2xl mb-1" style={{ color: '#1C1410' }}>China</p>
        <p className="font-black text-5xl font-mono tabular-nums mb-2" style={{ color: timerSecs <= 10 ? '#B8844A' : '#1C1410' }}>
          {mins}:{secs.toString().padStart(2, '0')}
        </p>
        <div className="w-full h-1.5 rounded-full overflow-hidden mb-4" style={{ backgroundColor: '#DDD4C0' }}>
          <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${(timerSecs / 90) * 100}%`, backgroundColor: timerSecs <= 10 ? '#B8844A' : '#B6871F' }} />
        </div>
        {/* Buttons */}
        <div className="flex gap-2">
          <button className="px-6 py-2.5 rounded-xl font-black text-sm text-white focus:outline-none" style={{ backgroundColor: '#2A5A3C' }}>▶ START</button>
          <button className="px-6 py-2.5 rounded-xl font-black text-sm focus:outline-none" style={{ backgroundColor: 'transparent', border: '1px solid #DDD4C0', color: '#1C1410' }}>NEXT →</button>
          <button className="px-3 py-2.5 rounded-xl font-black text-xs focus:outline-none" style={{ backgroundColor: 'transparent', border: '1px solid #DDD4C0', color: '#6A5A4A' }}>ADD TIME</button>
        </div>
      </div>
    </div>
  );
}

function DocumentsCard() {
  const [docTimer, setDocTimer] = useState(180);
  useEffect(() => {
    const t = setInterval(() => setDocTimer(s => s > 0 ? s - 1 : 180), 1000);
    return () => clearInterval(t);
  }, []);
  const m = Math.floor(docTimer / 60);
  const s = docTimer % 60;
  const shadow = { boxShadow: '0 24px 64px rgba(27,56,40,0.14)' };
  const pdfUrl = '/UNSC_RESOLUTION.pdf';
  return (
    <div className="w-full rounded-2xl overflow-hidden flex flex-row" style={{ ...shadow, minHeight: '460px', border: '1px solid #DDD4C0' }}>
      <div className="flex flex-col" style={{ width: '42%', borderRight: '1px solid #DDD4C0', backgroundColor: '#FAF8F3' }}>
        <div className="px-4 py-3" style={{ backgroundColor: '#1B3828' }}>
          <p className="font-black text-xs uppercase tracking-widest" style={{ color: '#EED98A', fontFamily: "'DM Mono', monospace" }}>READING TIME</p>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center px-4 py-6 text-center">
          <p className="text-[10px] font-mono tracking-widest uppercase mb-1" style={{ color: '#9A8A78' }}>S/RES/2819 (2026)</p>
          <p className="font-black text-xs uppercase mb-4" style={{ color: '#1C1410' }}>Libya Sanctions Resolution</p>
          <p className="font-mono text-3xl font-bold tabular-nums mb-1" style={{ color: '#1C1410' }}>{m}:{s.toString().padStart(2, '0')}</p>
          <p className="text-[10px] font-mono mb-4" style={{ color: '#9A8A78' }}>Reading Time</p>
          <div className="w-full h-1.5 rounded-full overflow-hidden" style={{ backgroundColor: '#DDD4C0' }}>
            <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${(docTimer / 180) * 100}%`, backgroundColor: '#1B3828' }} />
          </div>
          <div className="flex gap-2 mt-6 w-full">
            <button className="flex-1 py-2 rounded-xl font-black text-xs text-white" style={{ backgroundColor: '#2A5A3C' }}>▶ START</button>
            <button className="flex-1 py-2 rounded-xl font-black text-xs" style={{ backgroundColor: 'transparent', border: '1px solid #DDD4C0', color: '#6A5A4A' }}>SKIP →</button>
          </div>
        </div>
      </div>
      <div className="flex flex-col" style={{ flex: 1, backgroundColor: '#EDE7D8' }}>
        <div className="px-3 py-2 flex items-center justify-between" style={{ backgroundColor: '#DDD4C0', borderBottom: '1px solid #C8BAA8' }}>
          <span className="text-[10px] font-mono uppercase tracking-wide" style={{ color: '#6A5A4A' }}>Document</span>
          <span className="text-[10px] font-bold uppercase" style={{ color: '#1B3828' }}>Hide Doc</span>
        </div>
        <iframe
          src={pdfUrl}
          className="flex-1 w-full border-none"
          title="UNSC Resolution 2819 (2026)"
          style={{ minHeight: '380px' }}
        />
      </div>
    </div>
  );
}

function ChatCard() {
  const messages = [
    { sender: 'Chair', text: 'Welcome to the Security Council session on Nuclear Non-Proliferation.', time: '09:02', isChair: true },
    { sender: 'France', text: 'France is prepared to engage constructively on this matter.', time: '09:04', isChair: false },
    { sender: 'Chair', text: "You're doing great! Keep it up!", time: '09:06', isChair: true },
    { sender: 'Germany', text: 'Germany seconds the motion for a moderated caucus.', time: '09:07', isChair: false },
  ];
  const shadow = { boxShadow: '0 24px 64px rgba(27,56,40,0.14)' };
  const convs = ['Everyone', 'France', 'Germany'];
  return (
    <div className="w-full rounded-2xl overflow-hidden flex flex-row" style={{ ...shadow, minHeight: '460px', border: '1px solid #DDD4C0' }}>
      {/* Left panel — forest green */}
      <div className="flex flex-col flex-shrink-0" style={{ width: '140px', backgroundColor: '#1B3828', borderRight: '1px solid #3D7A52' }}>
        <div className="px-3 py-3" style={{ borderBottom: '1px solid rgba(61,122,82,0.4)' }}>
          <p className="font-black text-xs uppercase tracking-widest" style={{ color: '#EED98A', fontFamily: "'Outfit', sans-serif" }}>MESSAGES</p>
        </div>
        <div className="flex-1">
          {convs.map((c, i) => (
            <div key={c} className="px-3 py-2.5" style={{ backgroundColor: i === 0 ? 'rgba(238,217,138,0.12)' : 'transparent', borderLeft: i === 0 ? '3px solid #EED98A' : '3px solid transparent', borderBottom: '1px solid rgba(61,122,82,0.2)' }}>
              <p className="text-xs font-bold truncate" style={{ color: i === 0 ? '#EED98A' : '#A8C5B0' }}>{c}</p>
              <p className="text-[9px] truncate mt-0.5" style={{ color: 'rgba(168,197,176,0.6)' }}>{i === 0 ? 'Chair: Welcome...' : i === 1 ? 'France: Prepared...' : 'Germany: Seconds...'}</p>
            </div>
          ))}
        </div>
        <div className="px-2 py-2.5" style={{ borderTop: '1px solid rgba(61,122,82,0.4)' }}>
          <button className="w-full text-xs py-1.5 rounded-lg font-semibold" style={{ color: '#EED98A', border: '1px solid rgba(238,217,138,0.3)' }}>+ New message</button>
        </div>
      </div>
      {/* Right panel — ivory */}
      <div className="flex-1 flex flex-col" style={{ backgroundColor: '#FAF8F3' }}>
        <div className="px-4 py-3 flex-shrink-0" style={{ borderBottom: '1px solid #DDD4C0', backgroundColor: 'rgba(250,248,243,0.8)' }}>
          <p className="font-black text-sm" style={{ color: '#1B3828' }}>Everyone</p>
          <p className="text-[10px]" style={{ color: '#9A8A78' }}>4 messages</p>
        </div>
        <div className="flex-1 px-3 py-3 flex flex-col gap-2.5 overflow-hidden">
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.isChair ? 'justify-end' : 'justify-start'}`}>
              <div className={`flex flex-col max-w-[80%] gap-0.5 ${msg.isChair ? 'items-end' : 'items-start'}`}>
                <div className="px-3 py-2 rounded-2xl text-xs leading-snug" style={{
                  backgroundColor: msg.isChair ? '#1B3828' : '#EDE7D8',
                  color: msg.isChair ? '#EDE7D8' : '#1C1410',
                  borderBottomRightRadius: msg.isChair ? '4px' : '16px',
                  borderBottomLeftRadius: msg.isChair ? '16px' : '4px',
                  border: msg.isChair ? 'none' : '1px solid #DDD4C0',
                }}>
                  {msg.text}
                </div>
                <span className="text-[9px] font-mono" style={{ color: '#9A8A78' }}>{msg.isChair ? 'You' : msg.sender} · {msg.time}</span>
              </div>
            </div>
          ))}
        </div>
        <div className="px-3 pb-3 pt-2 flex gap-2 flex-shrink-0" style={{ borderTop: '1px solid #DDD4C0' }}>
          <div className="flex-1 rounded-xl px-3 py-2 text-xs" style={{ backgroundColor: '#EDE7D8', border: '1px solid #DDD4C0', color: '#9A8A78' }}>Message the committee…</div>
          <button className="px-3 py-2 rounded-xl text-xs font-black" style={{ backgroundColor: '#1B3828', color: '#EDE7D8' }}>→</button>
        </div>
      </div>
    </div>
  );
}

function ArchiveCard() {
  const base = 'w-full bg-[#FAF8F3] rounded-2xl border border-[#DDD4C0] overflow-hidden';
  const shadow = { boxShadow: '0 24px 64px rgba(27,56,40,0.14)' };
  return (
    <div className={base} style={{ ...shadow, minHeight: '460px' }}>
      <div className="bg-[#1B3828] px-5 py-3 flex items-center justify-between">
        <p className="text-[#EED98A] font-black text-sm uppercase tracking-wide">Session Archive</p>
        <span className="bg-[#3D7A52] text-white text-[9px] font-mono px-2 py-0.5 rounded-full uppercase tracking-widest">Coming Soon</span>
      </div>
      <div className="px-5 py-6 flex flex-col items-center text-center">
        <div className="w-14 h-14 rounded-2xl bg-[#EDE7D8] border border-[#DDD4C0] flex items-center justify-center mb-4">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#1B3828" strokeWidth="1.5"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M3 9h18M9 21V9"/></svg>
        </div>
        <h3 className="font-black text-[#1C1410] uppercase text-sm tracking-wide mb-2">Your Committee Dashboard</h3>
        <p className="text-[#6A5A4A] text-xs leading-relaxed mb-6 max-w-xs">Track sessions, statistics, and delegate progress all in one place.</p>
        <div className="flex flex-col gap-2.5 w-full">
          {['Saved Sessions', 'Session Statistics', 'My Progress'].map((label) => (
            <div key={label} className="flex items-center gap-3 bg-[#1B3828] rounded-xl px-4 py-3.5">
              <div className="w-2 h-2 rounded-full bg-[#EED98A] flex-shrink-0" />
              <span className="text-sm font-bold text-[#EED98A] uppercase tracking-wide flex-1 text-left">{label}</span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#EED98A" strokeWidth="2.5"><path d="M9 18l6-6-6-6"/></svg>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── MUN Globe ───────────────────────────────────────────────────────────────

const GLOBE_CITIES = [
  { name: 'The Hague',     lat: 52,  lng: 4,    delay: 0   },
  { name: 'New York',      lat: 40,  lng: -74,  delay: 0.3 },
  { name: 'London',        lat: 51,  lng: 0,    delay: 0.6 },
  { name: 'Singapore',     lat: 1,   lng: 103,  delay: 0.9 },
  { name: 'Tokyo',         lat: 35,  lng: 139,  delay: 1.2 },
  { name: 'Geneva',        lat: 46,  lng: 6,    delay: 0.2 },
  { name: 'Vienna',        lat: 48,  lng: 16,   delay: 0.5 },
  { name: 'Nairobi',       lat: -1,  lng: 36,   delay: 0.8 },
  { name: 'Buenos Aires',  lat: -34, lng: -58,  delay: 1.1 },
  { name: 'Sydney',        lat: -33, lng: 151,  delay: 1.4 },
];

function MUNGlobe() {
  const [rotation, setRotation] = useState(0);
  useEffect(() => {
    const iv = setInterval(() => setRotation(r => (r + 0.05) % 360), 100);
    return () => clearInterval(iv);
  }, []);

  const SIZE = 280;
  const cx = 140, cy = 140, r = 120;

  function normalize(lng: number): number {
    let v = ((lng + rotation) % 360 + 360) % 360;
    if (v > 180) v -= 360;
    return v;
  }

  function project(lat: number, lng: number) {
    const eff = normalize(lng);
    const x = cx + r * eff / 180 * (r / cx);
    const y = cy - r * lat / 90 * (r / cy);
    const dist = Math.sqrt((x - cx) ** 2 + (y - cy) ** 2);
    return { x, y, visible: Math.abs(eff) <= 90 && dist <= r + 2 };
  }

  const latLines = [-60, -30, 0, 30, 60].map(lat => {
    const y = cy - r * lat / 90 * (r / cy);
    return { lat, y };
  });

  const lngLines = Array.from({ length: 12 }, (_, i) => i * 30 - 150).map(lng => {
    const eff = normalize(lng);
    const x = cx + r * eff / 180 * (r / cx);
    return { lng, x, visible: Math.abs(eff) <= 90 };
  });

  return (
    <div className="w-[220px] h-[220px] md:w-[280px] md:h-[280px]">
      <svg viewBox={`0 0 ${SIZE} ${SIZE}`} width="100%" height="100%">
        <defs>
          <clipPath id="gc">
            <circle cx={cx} cy={cy} r={r} />
          </clipPath>
          <radialGradient id="gg" cx="40%" cy="35%" r="65%">
            <stop offset="0%" stopColor="rgba(61,122,82,0.4)" />
            <stop offset="70%" stopColor="rgba(27,56,40,0.2)" />
            <stop offset="100%" stopColor="rgba(0,0,0,0)" />
          </radialGradient>
        </defs>
        <circle cx={cx} cy={cy} r={r} fill="url(#gg)" />
        <g clipPath="url(#gc)" stroke="rgba(238,217,138,0.15)" strokeWidth="0.8" fill="none">
          {latLines.map(({ lat, y }) => (
            <line key={lat} x1={cx - r} y1={y} x2={cx + r} y2={y} />
          ))}
          {lngLines.filter(l => l.visible).map(({ lng, x }) => (
            <line key={lng} x1={x} y1={cy - r} x2={x} y2={cy + r} />
          ))}
        </g>
        <circle cx={cx} cy={cy} r={r} fill="none" stroke="rgba(238,217,138,0.2)" strokeWidth="1.5" />
        {GLOBE_CITIES.map(city => {
          const { x, y, visible } = project(city.lat, city.lng);
          return (
            <g key={city.name} opacity={visible ? 1 : 0}>
              <circle
                cx={x} cy={y} r={7}
                fill="none" stroke="#EED98A" strokeWidth="1"
                style={{
                  animation: `globePulse 2s ease-in-out ${city.delay}s infinite`,
                  transformBox: 'fill-box' as never,
                  transformOrigin: 'center',
                }}
              />
              <circle cx={x} cy={y} r={3} fill="#EED98A" />
            </g>
          );
        })}
      </svg>
    </div>
  );
}

function FeatureCard({ id }: { id: string }) {
  if (id === 'roll-call') return <RollCallCard />;
  if (id === 'motions') return <MotionsCard />;
  if (id === 'speakers') return <SpeakersCard />;
  if (id === 'documents') return <DocumentsCard />;
  if (id === 'chat') return <ChatCard />;
  if (id === 'archive') return <ArchiveCard />;
  return null;
}

function FeatureCarousel({
  activeFeature,
}: {
  activeFeature: string;
  setActiveFeature: (id: string) => void;
}) {
  const featureIds = ['roll-call', 'motions', 'speakers', 'documents', 'chat', 'archive'];
  return (
    <div className="relative" style={{ height: '520px' }}>
      {featureIds.map((id) => (
        <div
          key={id}
          className="absolute inset-0"
          style={{
            opacity: id === activeFeature ? 1 : 0,
            transform: id === activeFeature ? 'translateY(0px) scale(1)' : 'translateY(20px) scale(0.97)',
            transition: 'opacity 0.4s cubic-bezier(0.4,0,0.2,1), transform 0.4s cubic-bezier(0.4,0,0.2,1)',
            pointerEvents: id === activeFeature ? 'auto' : 'none',
          }}
        >
          <FeatureCard id={id} />
        </div>
      ))}
    </div>
  );
}

// ── Main page ────────────────────────────────────────────────────────────────

export default function HomeClient() {
  const router = useRouter();
  const [joinCode, setJoinCode] = useState('');
  const [activeFeature, setActiveFeature] = useState('roll-call');
  const handleJoin = () => {
    const code = joinCode.trim().toUpperCase();
    if (code.length >= 4) {
      const isChairCode = code.includes('-') && code.split('-').pop()?.length === 4;
      if (isChairCode) {
        router.push(`/join?code=${encodeURIComponent(code)}&mode=chair`);
      } else {
        router.push(`/join?code=${encodeURIComponent(code)}`);
      }
    }
  };

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );
    document.querySelectorAll('.scroll-reveal').forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'WebApplication',
            name: 'Gavelling',
            url: 'https://gavelling.com',
            description: 'Modern MUN committee software. Manage roll call, speakers lists, motions, and voting — all in one place.',
            applicationCategory: 'EducationalApplication',
            operatingSystem: 'Web',
            offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' },
            author: { '@type': 'Organization', name: 'Gavelling', url: 'https://gavelling.com', email: 'wearegavelling@gmail.com' },
          }),
        }}
      />
      <style>{`
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(24px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes textReveal {
          0%   { opacity: 0; transform: translateY(28px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        .text-reveal-3 { animation: textReveal 0.6s cubic-bezier(0.4,0,0.2,1) both 1.9s; }
        .text-reveal-4 { animation: textReveal 0.6s cubic-bezier(0.4,0,0.2,1) both 2.1s; }
        .text-reveal-5 { animation: textReveal 0.6s cubic-bezier(0.4,0,0.2,1) both 2.3s; }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(32px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        .scroll-reveal { opacity: 0; }
        .scroll-reveal.visible { animation: fadeInUp 0.7s cubic-bezier(0.4, 0, 0.2, 1) both; }
        .scroll-reveal.visible:nth-child(2) { animation-delay: 0.1s; }
        .scroll-reveal.visible:nth-child(3) { animation-delay: 0.2s; }
        @keyframes globePulse {
          0%, 100% { opacity: 0.7; transform: scale(1); }
          50% { opacity: 0.1; transform: scale(1.8); }
        }
      `}</style>

      <div className="min-h-screen bg-[#EDE7D8] flex flex-col relative overflow-x-hidden">
        <div className="relative z-10 flex flex-col">

          {/* Grain overlay */}
          <div
            className="pointer-events-none fixed inset-0 z-[1]"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300'%3E%3Cfilter id='grain'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='300' height='300' filter='url(%23grain)' opacity='1'/%3E%3C/svg%3E")`,
              backgroundRepeat: 'repeat',
              backgroundSize: '300px 300px',
              mixBlendMode: 'multiply',
              opacity: 0.18,
            }}
          />

          <SiteNav />

          {/* Hero */}
          <section className="relative z-10 flex flex-col items-center justify-center overflow-hidden" style={{ height: 'calc(100vh - 72px)' }}>
            <div className="absolute inset-0 z-0">
              <video autoPlay muted playsInline className="absolute inset-0 w-full h-full object-cover" style={{ opacity: 0.55 }}>
                <source src="/hero_no_audio.webm" type="video/webm" />
                <source src="/hero_no_audio.mp4" type="video/mp4" />
              </video>
              <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse 70% 70% at 50% 50%, transparent 40%, rgba(237,231,216,0.6) 70%, rgba(237,231,216,0.95) 100%)' }} />
              <div className="absolute bottom-0 left-0 right-0 h-48" style={{ background: 'linear-gradient(to bottom, transparent, #EDE7D8)' }} />
              <div className="absolute top-0 left-0 bottom-0 w-[55%]" style={{ background: 'linear-gradient(to right, rgba(237,231,216,0.85) 0%, rgba(237,231,216,0.5) 60%, transparent 100%)' }} />
              <div className="absolute top-0 left-0 right-0 h-40" style={{ background: 'linear-gradient(to bottom, rgba(237,231,216,0.98) 0%, rgba(237,231,216,0.7) 50%, transparent 100%)' }} />
            </div>

            <div className="relative z-10 flex items-center px-8 md:px-14">
              <div className="flex flex-col justify-center items-center text-center w-full max-w-2xl mx-auto">
                <h1 className="font-black tracking-tight text-white leading-[1.05] mb-5 text-center md:whitespace-nowrap" style={{ fontSize: 'clamp(48px, 13.5vw, 165px)' }}>
                  MUN done{' '}
                  <span style={{ fontFamily: "'Playfair Display', serif", fontStyle: 'italic', fontWeight: 400, color: '#B8844A' }}>
                    right.
                  </span>
                </h1>
                <p className="text-reveal-3 text-lg max-w-lg mb-6 leading-relaxed font-medium text-center text-[#1B3828]" style={{
                  opacity: 0,
                  backgroundColor: 'rgba(246,241,233,0.55)',
                  backdropFilter: 'blur(4px)',
                  WebkitBackdropFilter: 'blur(4px)',
                  borderRadius: '12px',
                  padding: '10px 20px',
                }}>
                  The most user-friendly way to run your MUN committee.
                </p>
                <button
                  onClick={() => router.push('/create')}
                  className="text-reveal-4 bg-[#1B3828] hover:bg-[#2A5A3C] active:scale-[0.98] text-[#EED98A] px-10 py-5 rounded-2xl font-black text-xl transition-all shadow-lg shadow-[#1B3828]/20 mb-5 w-fit mx-auto"
                  style={{ opacity: 0 }}
                >
                  START YOUR COMMITTEE →
                </button>
                <div className="text-reveal-5 flex flex-col gap-2 w-fit items-center" style={{
                  opacity: 0,
                  background: 'rgba(237,231,216,0.45)',
                  backdropFilter: 'blur(6px)',
                  WebkitBackdropFilter: 'blur(6px)',
                  borderRadius: '14px',
                  padding: '12px 20px',
                }}>
                  <p className="text-xs text-[#1B3828] tracking-[0.16em] uppercase font-semibold" style={{ fontFamily: "'DM Mono', monospace" }}>Join a Session</p>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="SESSION CODE"
                      value={joinCode}
                      onChange={(e) => setJoinCode(e.target.value.toUpperCase().slice(0, 20))}
                      onKeyDown={(e) => { if (e.key === 'Enter') handleJoin(); }}
                      maxLength={20}
                      className="bg-[#FAF8F3]/90 border border-[#DDD4C0] focus:border-[#1B3828] rounded-xl px-4 py-3 text-[#1C1410] placeholder-[#9A8A78] focus:outline-none text-sm tracking-widest uppercase text-center transition-colors w-44 backdrop-blur-sm"
                      style={{ fontFamily: "'DM Mono', monospace" }}
                    />
                    <button
                      onClick={handleJoin}
                      disabled={joinCode.trim().length < 4}
                      className="bg-[#1B3828] hover:bg-[#2A5A3C] disabled:opacity-40 text-[#EED98A] px-5 py-3 rounded-xl font-bold text-sm transition-colors"
                    >
                      JOIN →
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* How it works */}
          <section className="relative z-10 bg-[#1B3828] pt-24 pb-20 px-6" style={{ marginTop: '-2px', paddingBottom: '120px' }}>
            <div>
              <div className="max-w-4xl mx-auto">
                <div className="text-center mb-14">
                  <h2 className="scroll-reveal text-5xl font-black text-white mb-4 uppercase tracking-wider">Up and Running in Minutes</h2>
                  <p className="scroll-reveal text-[#EED98A]/70 text-lg mb-4">No downloads, no setup. Just open your browser and start chairing.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-[#B6871F]/30 w-full max-w-6xl mx-auto mt-16">
                  {steps.map((s) => (
                    <div key={s.step} className="scroll-reveal text-center px-6 md:px-16 py-8 group relative overflow-hidden cursor-default flex flex-col items-center">
                      <div className="relative w-full flex justify-center mb-2 h-8">
                        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-16 h-1.5 rounded-full bg-[#B6871F] opacity-0 group-hover:opacity-100 transition-all duration-300 shadow-[0_0_20px_6px_rgba(182,135,31,0.5)]" />
                        <div
                          className="absolute top-1.5 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-all duration-500"
                          style={{
                            width: '180px',
                            height: '120px',
                            background: 'linear-gradient(to bottom, rgba(182,135,31,0.25) 0%, transparent 100%)',
                            clipPath: 'polygon(30% 0%, 70% 0%, 100% 100%, 0% 100%)',
                            borderRadius: '0 0 50% 50%',
                            filter: 'blur(8px)',
                          }}
                        />
                      </div>
                      <div className="text-7xl font-black text-[#2A5A3C]/40 mb-6 transition-all duration-300 group-hover:text-[#B6871F]/60 group-hover:scale-110 leading-none">{s.step}</div>
                      <h3 className="text-2xl font-black text-white mb-4 uppercase tracking-wider">{s.title}</h3>
                      <p className="text-[#EED98A] text-base leading-relaxed opacity-0 group-hover:opacity-100 transition-all duration-400 transform translate-y-3 group-hover:translate-y-0 max-w-xs mx-auto">{s.desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* ── FEATURE SHOWCASE SECTION ── */}
          <section id="features" className="relative z-10 bg-[#EDE7D8] px-8 md:px-16 scroll-reveal">
            <div className="w-full flex flex-col md:flex-row gap-12 items-center min-h-[calc(100vh-72px)]">

              {/* LEFT — text + pills centered */}
              <div className="w-full md:w-80 flex-shrink-0 flex flex-col justify-center items-start py-8">

                <h2 className="font-black uppercase tracking-wide leading-tight mb-4" style={{ fontSize: 'clamp(28px, 3.2vw, 48px)' }}>
                  <span className="text-[#1B3828]">Everything chairs need</span><br />
                  <span className="text-[#B8844A]">to run committees</span>
                </h2>

                <p className="text-[#6A5A4A] text-sm mb-5 leading-relaxed">
                  One dashboard. Every tool. From opening session to final voting.
                </p>

                {/* Pills */}
                <div className="flex flex-col gap-1.5 w-full">
                  {[
                    { id: 'roll-call', icon: <Mic size={15} className="text-[#EED98A]" />, label: 'Roll Call' },
                    { id: 'motions', icon: <Scale size={15} className="text-[#EED98A]" />, label: 'Motions & Voting' },
                    { id: 'speakers', icon: <List size={15} className="text-[#EED98A]" />, label: 'Speakers List' },
                    { id: 'documents', icon: <FileText size={15} className="text-[#EED98A]" />, label: 'Document Upload' },
                    { id: 'chat', icon: <MessageSquare size={15} className="text-[#EED98A]" />, label: 'Live Chat' },
                    { id: 'archive', icon: <Save size={15} className="text-[#EED98A]" />, label: 'Archives' },
                  ].map((f) => (
                    <div
                      key={f.id}
                      className={`flex items-center gap-3 rounded-xl px-4 cursor-pointer transition-all duration-300 border ${
                        activeFeature === f.id
                          ? 'bg-[#2A5A3C] border-[#3D7A52] py-2.5 shadow-lg shadow-[#1B3828]/20'
                          : 'bg-[#1B3828] border-[#1B3828] py-2 hover:bg-[#2A5A3C]'
                      }`}
                      onClick={() => setActiveFeature(f.id)}
                    >
                      <span className="flex items-center justify-center w-4 h-4 flex-shrink-0">{f.icon}</span>
                      <span className="text-xs font-bold text-[#EED98A] uppercase tracking-wide">{f.label}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* RIGHT — click-only carousel, wider */}
              <div className="flex-1 flex justify-center items-center py-8">
                <div className="w-full" style={{ maxWidth: '680px' }}>
                  <FeatureCarousel activeFeature={activeFeature} setActiveFeature={setActiveFeature} />
                </div>
              </div>

            </div>
          </section>

          {/* ── CONFERENCES SECTION ── */}
          <section className="relative z-10 bg-[#1B3828] px-6 md:px-14 py-24 overflow-hidden">
            {/* Grain */}
            <div className="pointer-events-none absolute inset-0" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300'%3E%3Cfilter id='cg'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='300' height='300' filter='url(%23cg)' opacity='1'/%3E%3C/svg%3E")`, backgroundRepeat: 'repeat', backgroundSize: '300px 300px', mixBlendMode: 'overlay', opacity: 0.07 }} />

            <div className="relative max-w-6xl mx-auto">

              {/* Part A — Eyebrow + heading */}
              <div className="mb-14">
                <p className="text-[11px] tracking-[0.2em] mb-3" style={{ color: '#EED98A', fontFamily: "'DM Mono', monospace" }}>MUN CONFERENCES</p>
                <h2 style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 900, fontSize: 'clamp(32px, 4vw, 56px)', lineHeight: 1.05 }}>
                  <span className="block text-white">Run your conference.</span>
                  <span className="block" style={{ color: '#EED98A' }}>Fee-free for organisers.</span>
                </h2>
                <p className="mt-4 text-base leading-relaxed" style={{ color: 'rgba(237,231,216,0.7)', maxWidth: '520px', fontFamily: "'Outfit', sans-serif" }}>
                  Gavelling handles registration, allocations, session management, and payments — so you can focus on running a great conference.
                </p>
              </div>

              {/* Part B — 2×2 feature cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-20">
                {[
                  { icon: <Users size={22} color="#EED98A" />, title: 'Smart Delegate Assignment', desc: 'Preferences, experience scores, and one-click auto-assign. No more spreadsheets.' },
                  { icon: <FileText size={22} color="#EED98A" />, title: 'Document Portal', desc: 'Study guides, position papers, and feedback — all in one place, not scattered across email.' },
                  { icon: <CreditCard size={22} color="#EED98A" />, title: 'Fee-Free for Organisers', desc: 'Zero platform fees. A transparent 5% surcharge is added for delegates, waived with Gavelling Unlimited.' },
                  { icon: <Zap size={22} color="#EED98A" />, title: 'Automated Everything', desc: 'Acceptance emails, allocation codes, reminders, and receipts — all sent automatically.' },
                ].map(card => (
                  <div key={card.title} style={{ backgroundColor: 'rgba(255,255,255,0.05)', border: '1px solid rgba(238,217,138,0.15)', borderRadius: '12px', padding: '20px 24px' }}>
                    <div className="mb-3">{card.icon}</div>
                    <h3 className="font-semibold text-base mb-1 text-white" style={{ fontFamily: "'Outfit', sans-serif" }}>{card.title}</h3>
                    <p className="text-sm leading-relaxed" style={{ color: 'rgba(237,231,216,0.65)', fontFamily: "'Outfit', sans-serif" }}>{card.desc}</p>
                  </div>
                ))}
              </div>

              {/* Part C — Globe + Global reach */}
              <div className="flex flex-col md:flex-row gap-12 items-center mb-20">
                <div className="flex-1">
                  <p className="text-[10px] tracking-[0.2em] mb-2" style={{ color: 'rgba(238,217,138,0.6)', fontFamily: "'DM Mono', monospace" }}>GLOBAL REACH</p>
                  <h3 className="font-black text-3xl md:text-4xl text-white mb-3" style={{ fontFamily: "'Outfit', sans-serif" }}>MUN Across the World</h3>
                  <p className="text-sm leading-relaxed mb-6" style={{ color: 'rgba(237,231,216,0.7)', fontFamily: "'Outfit', sans-serif" }}>
                    Conferences from The Hague to Singapore, Tokyo to New York. Find your next conference or list yours — the MUN community is global.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <Link
                      href="/conferences"
                      className="rounded-xl py-3 px-6 font-bold text-sm text-center transition-all focus:outline-none"
                      style={{ border: '1.5px solid rgba(238,217,138,0.4)', color: '#EED98A', backgroundColor: 'transparent', fontFamily: "'Outfit', sans-serif", letterSpacing: '0.08em', textDecoration: 'none', display: 'inline-block' }}
                      onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = 'rgba(238,217,138,0.08)'; }}
                      onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = 'transparent'; }}
                    >
                      EXPLORE CONFERENCES →
                    </Link>
                    <Link
                      href="/conferences/new"
                      className="rounded-xl py-3 px-6 font-bold text-sm text-center transition-all focus:outline-none"
                      style={{ backgroundColor: '#EED98A', color: '#1B3828', fontFamily: "'Outfit', sans-serif", letterSpacing: '0.08em', textDecoration: 'none', display: 'inline-block' }}
                      onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = 'white'; }}
                      onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = '#EED98A'; }}
                    >
                      ORGANISE A CONFERENCE →
                    </Link>
                  </div>
                </div>
                <div className="flex-shrink-0 flex items-center justify-center">
                  <MUNGlobe />
                </div>
              </div>

              {/* Part D — Job board teaser */}
              <div
                className="flex flex-col md:flex-row md:items-center gap-6"
                style={{ backgroundColor: 'rgba(0,0,0,0.2)', border: '1px solid rgba(238,217,138,0.12)', borderRadius: '16px', padding: '32px 40px' }}
              >
                <div className="flex-1">
                  <p className="text-[10px] tracking-[0.2em] mb-2" style={{ color: 'rgba(238,217,138,0.6)', fontFamily: "'DM Mono', monospace" }}>CHAIR & STAFF BOARD</p>
                  <h3 className="font-black text-2xl text-white mb-2" style={{ fontFamily: "'Outfit', sans-serif" }}>Looking to chair? Find your next role.</h3>
                  <p className="text-sm leading-relaxed" style={{ color: 'rgba(237,231,216,0.65)', fontFamily: "'Outfit', sans-serif" }}>
                    Conferences post open positions for chairs, secretariat, and staff. Apply directly through your Gavelling profile.
                  </p>
                </div>
                <div className="flex-shrink-0">
                  <Link
                    href="/conferences#jobs"
                    className="rounded-xl py-3 px-8 font-bold text-sm transition-all focus:outline-none"
                    style={{ border: '1.5px solid rgba(238,217,138,0.35)', color: '#EED98A', backgroundColor: 'transparent', fontFamily: "'Outfit', sans-serif", letterSpacing: '0.08em', textDecoration: 'none', display: 'inline-block' }}
                    onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = 'rgba(238,217,138,0.08)'; }}
                    onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.backgroundColor = 'transparent'; }}
                  >
                    FIND A ROLE →
                  </Link>
                </div>
              </div>

            </div>
          </section>

          {/* Footer */}
          <footer
            className="relative z-10 border-t border-[#DDD4C0] px-6 py-8"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300'%3E%3Cfilter id='grain'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='300' height='300' filter='url(%23grain)' opacity='0.18'/%3E%3C/svg%3E")`,
              backgroundRepeat: 'repeat',
              backgroundSize: '300px 300px',
              backgroundColor: '#F6F1E9',
            }}
          >
            <div className="flex flex-col items-center gap-4 md:grid md:grid-cols-3 md:gap-0 md:items-center">
              <img
                src="/GavellingLogo.png"
                alt="Gavelling"
                className="h-7 w-auto"
                style={{ filter: 'brightness(0) saturate(100%) invert(18%) sepia(25%) saturate(800%) hue-rotate(100deg) brightness(85%)' }}
                onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
              />
              <div className="flex items-center justify-center gap-4">
                <a href="https://www.instagram.com/wearegavelling/" target="_blank" rel="noopener noreferrer"
                  aria-label="Instagram"
                  style={{ color: '#9A8A78', transition: 'color 0.15s' }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLAnchorElement).style.color = '#1B3828'; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLAnchorElement).style.color = '#9A8A78'; }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/>
                  </svg>
                </a>
                <span aria-label="LinkedIn (coming soon)" style={{ color: '#C8BFB0', cursor: 'default' }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/>
                  </svg>
                </span>
              </div>
              <p className="text-xs font-semibold text-[#1B3828] md:text-right">© {new Date().getFullYear()} Gavelling. Built for the MUN community.</p>
            </div>
          </footer>

        </div>
      </div>

    </>
  );
}
